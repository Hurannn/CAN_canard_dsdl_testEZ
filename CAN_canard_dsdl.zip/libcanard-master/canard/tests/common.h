#pragma once

#define CANARD_STATIC_ASSERT static_assert
#define CANARD_ASSERT assert
#define DRONECAN_CXX_WRAPPERS
